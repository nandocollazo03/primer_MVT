from django.http import HttpResponse
from django.shortcuts import render
import datetime
from datosFamiliares.models import Familiar
from django.template import Context, Template, loader

def familiar(self):
    familiar1 = Familiar(nombre = "Rodolfo", edad = 24, fecha_de_nacimiento = "1998-10-14")
    familiar1.save()

    familiar2 = Familiar(nombre = "Rigoberta", edad = 35, fecha_de_nacimiento = "1987-12-16")
    familiar2.save()

    familiar3 = Familiar(nombre = "Florencia", edad = 17, fecha_de_nacimiento = "2005-8-24")
    familiar3.save()

    #lista_de_familiares = [familiar1, familiar2, familiar3]

    #diccionario = {'familiares': familiar1, 'familiar2': familiar2, 'familiar3': familiar3}
    texto = f"<h1>Familiares ingresados:</h1><br>{familiar1.nombre} - edad: {familiar1.edad} - Fecha de nacimiento: {familiar1.fecha_de_nacimiento}<br>{familiar2.nombre} - edad: {familiar2.edad} - Fecha de nacimiento: {familiar2.fecha_de_nacimiento}<br>{familiar3.nombre} - edad: {familiar3.edad} - Fecha de nacimiento: {familiar3.fecha_de_nacimiento}"

    #plantilla = loader.get_template('template_01.html')
    #documento = plantilla.render(diccionario)


    return HttpResponse(texto)